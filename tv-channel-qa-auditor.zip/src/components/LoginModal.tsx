import { useState } from 'react';

interface LoginModalProps {
  onLoginSuccess: (user: {
    id: string;
    username: string;
    fullName: string;
    role: string;
    sessionToken?: string;
  }) => void;
}

export function LoginModal({ onLoginSuccess }: LoginModalProps) {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin123');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Authentication failed');
      onLoginSuccess({
        ...data.user,
        sessionToken: data.sessionToken,
      });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#141413]/45 p-4">
      <div className="w-full max-w-sm rounded-[3px] border border-[#D4CFC5] bg-white p-7 text-[#141413] space-y-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="inline-block h-2.5 w-2.5 rounded-[1px] bg-[#C83A1B]" aria-hidden="true" />
            <span className="font-display text-sm font-bold tracking-[-0.02em] text-[#DC2626]">
              TV-TASKVERIFY
            </span>
          </div>
          <h1 className="font-display text-xl font-semibold tracking-[-0.02em] text-[#141413]">
            Operator Sign In
          </h1>
          <p className="text-xs text-[#78716C]">
            Sign in with your station account to manage channels and QA records.
          </p>
        </div>

        {error && (
          <div className="rounded-[3px] border border-[#FCA5A5] bg-[#FEF2F2] px-3.5 py-2.5 text-xs text-[#B91C1C]">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-medium text-[#57534E] mb-1.5">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full rounded-[3px] border border-[#D4CFC5] bg-white px-3 py-2 text-xs text-[#141413] focus:border-[#141413] focus:outline-none"
              required
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-[#57534E] mb-1.5">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full rounded-[3px] border border-[#D4CFC5] bg-white px-3 py-2 text-xs text-[#141413] focus:border-[#141413] focus:outline-none"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-[3px] bg-[#C83A1B] py-2.5 text-xs font-medium text-white hover:bg-[#A82E13] transition-colors disabled:opacity-50"
          >
            {loading ? 'Signing in…' : 'Sign In'}
          </button>
        </form>

        <div className="border-t border-[#EFECE6] pt-3 text-[11px] text-[#78716C] flex items-center justify-between">
          <span>Default operator</span>
          <span className="font-mono text-[#57534E]">admin / admin123</span>
        </div>
      </div>
    </div>
  );
}
