using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Xml;
using System.Xml.Linq;

namespace BroadcastQA.Wpf.Services;

public enum FileRole
{
    Metadata,
    TCommercial,
    TrCommercial,
    TrSchedule,
    TrScheduleDeleted,
    SelectedChannels,
    ReviewedCaptions,
    SchemaOnly,
    Unknown,
    Invalid
}

public sealed record ParsedXmlRecord(
    Dictionary<string, string> CanonicalFields,
    Dictionary<string, string> ExtraFields,
    string RawXml,
    string EntryType
);

public sealed record XmlFileInspection(
    string FileName,
    string RelativePath,
    string Sha256,
    FileRole Role,
    bool HasInlineSchema,
    string? RootElement,
    string? RecordElement,
    List<(string Name, string Type)> SchemaFields,
    List<string> UnmappedFields,
    List<string> Errors,
    List<ParsedXmlRecord> Records
);

public sealed class XmlAutosaveParser
{
    private static readonly Dictionary<string, string> AliasMap = new(StringComparer.OrdinalIgnoreCase)
    {
        ["MasterEntryID"] = "MasterEntryID", ["segmentDetailID"] = "segmentDetailID",
        ["startIndex"] = "startIndex", ["endIndex"] = "endIndex", ["DiffInIndex"] = "DiffInIndex",
        ["startTime"] = "startTime", ["endTime"] = "endTime", ["Duration"] = "Duration",
        ["channelID"] = "channelID", ["channelName"] = "channelName", ["transDate"] = "transDate",
        ["captionID"] = "captionID", ["captionName"] = "captionName", ["brandName"] = "brandName",
        ["FilePath"] = "FilePath", ["EntryType"] = "EntryType", ["videoClipID"] = "videoClipID",
        ["startFrame"] = "startFrame", ["endFrame"] = "endFrame", ["txt"] = "txt",
        ["startTime_tts"] = "startTime_tts", ["endTime_tts"] = "endTime_tts",
        ["categoryName"] = "categoryName", ["subcategoryName"] = "subcategoryName",
        ["categoryID"] = "categoryID", ["subcategoryID"] = "subcategoryID",
        ["brandID"] = "brandID", ["commercialTypeID"] = "commercialTypeID",
        ["Action"] = "Action", ["commercialID"] = "commercialID",
        ["videoFileName"] = "videoFileName", ["leftAdjust"] = "leftAdjust", ["rightAdjust"] = "rightAdjust",
        ["qualityID"] = "qualityID", ["matchValue"] = "matchValue", ["fdb"] = "fdb",
        ["isBenchMarked"] = "isBenchMarked", ["companyName"] = "companyName",
        ["customDuration"] = "customDuration", ["commercialTypeName"] = "commercialTypeName",
        ["MatchCoverage"] = "MatchCoverage", ["SourceDuration"] = "SourceDuration"
    };

    public XmlFileInspection ParseFile(string fullPath, string baseFolder)
    {
        var bytes = File.ReadAllBytes(fullPath);
        var sha256 = Convert.ToHexString(SHA256.HashData(bytes)).ToLowerInvariant();
        var relPath = Path.GetRelativePath(baseFolder, fullPath);
        var fileName = Path.GetFileName(fullPath);

        var errors = new List<string>();
        var schemaFields = new List<(string Name, string Type)>();
        var unmapped = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var records = new List<ParsedXmlRecord>();

        try
        {
            var settings = new XmlReaderSettings
            {
                DtdProcessing = DtdProcessing.Prohibit,
                XmlResolver = null,
                IgnoreComments = true,
                IgnoreWhitespace = true
            };

            using var ms = new MemoryStream(bytes);
            using var reader = XmlReader.Create(ms, settings);
            var doc = XDocument.Load(reader, LoadOptions.None);
            var root = doc.Root;
            if (root is null)
            {
                errors.Add("Missing XML root element.");
                return new XmlFileInspection(fileName, relPath, sha256, FileRole.Invalid, false, null, null, schemaFields, [], errors, records);
            }

            if (string.Equals(root.Name.LocalName, "schema", StringComparison.OrdinalIgnoreCase))
            {
                ExtractSchema(root, schemaFields);
                return new XmlFileInspection(fileName, relPath, sha256, FileRole.SchemaOnly, true, root.Name.ToString(), null, schemaFields, [], errors, records);
            }

            var hasInlineSchema = false;
            var schemaEls = root.Elements().Where(e => string.Equals(e.Name.LocalName, "schema", StringComparison.OrdinalIgnoreCase)).ToList();
            foreach (var s in schemaEls)
            {
                hasInlineSchema = true;
                ExtractSchema(s, schemaFields);
                s.Remove();
            }

            // Unwrap diffgram if present
            var dataRoot = root.Elements().FirstOrDefault(e => string.Equals(e.Name.LocalName, "diffgram", StringComparison.OrdinalIgnoreCase))?.Elements().FirstOrDefault() ?? root;
            string? recordElement = null;

            foreach (var rowEl in dataRoot.Elements())
            {
                if (!rowEl.HasElements && !rowEl.HasAttributes) continue;
                recordElement ??= rowEl.Name.LocalName;

                var canonical = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                var extra = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);

                foreach (var child in rowEl.Elements())
                {
                    var tag = child.Name.LocalName;
                    var val = child.Value.Trim();
                    if (AliasMap.TryGetValue(tag, out var mapped))
                        canonical[mapped] = val;
                    else
                    {
                        if (!string.IsNullOrEmpty(val)) extra[tag] = val;
                        unmapped.Add(tag);
                    }
                }

                var rolePreview = DetectRole(fileName, root.Name.LocalName, recordElement, canonical.Keys);
                var entryType = ClassifyEntryType(canonical, rolePreview);
                records.Add(new ParsedXmlRecord(canonical, extra, rowEl.ToString(), entryType));
            }

            var role = DetectRole(fileName, root.Name.LocalName, recordElement, records.SelectMany(r => r.CanonicalFields.Keys));
            return new XmlFileInspection(fileName, relPath, sha256, role, hasInlineSchema, root.Name.ToString(), recordElement, schemaFields, unmapped.ToList(), errors, records);
        }
        catch (Exception ex)
        {
            errors.Add(ex.Message);
            return new XmlFileInspection(fileName, relPath, sha256, FileRole.Invalid, false, null, null, schemaFields, [], errors, records);
        }
    }

    private static void ExtractSchema(XElement schemaRoot, List<(string Name, string Type)> target)
    {
        foreach (var el in schemaRoot.Descendants().Where(x => string.Equals(x.Name.LocalName, "element", StringComparison.OrdinalIgnoreCase)))
        {
            var name = el.Attribute("name")?.Value;
            var type = el.Attribute("type")?.Value ?? "string";
            if (!string.IsNullOrWhiteSpace(name) && !string.Equals(name, "NewDataSet", StringComparison.OrdinalIgnoreCase))
                target.Add((name, type));
        }
    }

    private static FileRole DetectRole(string fileName, string root, string? recordEl, IEnumerable<string> fields)
    {
        var lower = fileName.ToLowerInvariant();
        if (lower.Contains("metadata") || root.Contains("metadata", StringComparison.OrdinalIgnoreCase)) return FileRole.Metadata;
        if (lower.Contains("selectedchannel")) return FileRole.SelectedChannels;
        if (lower.Contains("reviewed_caption")) return FileRole.ReviewedCaptions;
        if (lower.Contains("deleted")) return FileRole.TrScheduleDeleted;
        if (lower.Contains("trcommercial")) return FileRole.TrCommercial;
        if (lower.Contains("tcommercial")) return FileRole.TCommercial;
        if (lower.Contains("trschedule")) return FileRole.TrSchedule;
        var set = fields.ToHashSet(StringComparer.OrdinalIgnoreCase);
        if (set.Contains("channelName") && !set.Contains("startTime")) return FileRole.SelectedChannels;
        if (set.Contains("commercialID") && !set.Contains("startTime")) return FileRole.TCommercial;
        if (set.Contains("startTime")) return FileRole.TrSchedule;
        return FileRole.Unknown;
    }

    private static bool IsMeaningful(string? v)
    {
        if (string.IsNullOrWhiteSpace(v)) return false;
        var u = v.Trim().ToUpperInvariant();
        return u is not ("0" or "-1" or "NULL" or "NONE" or "N/A" or "-");
    }

    private static string ClassifyEntryType(Dictionary<string, string> c, FileRole role)
    {
        foreach (var key in new[] { "EntryType", "commercialTypeName", "categoryName", "subcategoryName" })
        {
            if (!c.TryGetValue(key, out var raw) || string.IsNullOrWhiteSpace(raw)) continue;
            var u = raw.Trim().ToUpperInvariant();
            if (u.Contains("SPN") || u.Contains("SPONSOR")) return "SPN";
            if (u.Contains("PROMO") || u.Contains("TRAILER") || u.Contains("TEASER")) return "PROMO";
            if (u.Contains("NON-COMMERCIAL") || u.Contains("NON COMMERCIAL")) return "PROGRAM";
            if (u is "AD" or "ADV" or "TVC" or "SPOT" or "COM" or "ADVERTISEMENT" || u.Contains("COMMERCIAL") || u.Contains("ADVERT")) return "ADVERTISEMENT";
            if (u is "P" or "PRG" or "PGM" or "PROG" or "PROGRAM" or "SHOW" or "REGULAR" or "TX"
                || u.Contains("PROGRAM") || u.Contains("SHOW") || u.Contains("NEWS") || u.Contains("DRAMA")
                || u.Contains("SERIAL") || u.Contains("MOVIE") || u.Contains("FILM") || u.Contains("TALK")
                || u.Contains("CURRENT AFFAIR") || u.Contains("ENTERTAINMENT") || u.Contains("SPORT")
                || u.Contains("RELIGIOUS") || u.Contains("ISLAMIC") || u.Contains("DOCUMENTARY")
                || u.Contains("COMEDY") || u.Contains("MUSIC") || u.Contains("KIDS"))
                return "PROGRAM";
        }
        if (role is FileRole.TrCommercial or FileRole.TCommercial) return "ADVERTISEMENT";
        if ((c.TryGetValue("commercialID", out var cid) && IsMeaningful(cid))
            || (role != FileRole.ReviewedCaptions && c.TryGetValue("brandName", out var bn) && IsMeaningful(bn)))
            return "ADVERTISEMENT";
        if (role is FileRole.TrSchedule or FileRole.TrScheduleDeleted or FileRole.ReviewedCaptions
            || (c.TryGetValue("captionName", out var cn) && IsMeaningful(cn)))
            return "PROGRAM";
        return "OTHER";
    }
}
