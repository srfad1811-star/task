using ClosedXML.Excel;

namespace BroadcastQA.Wpf.Services;

public sealed class ExcelExportService
{
    public void ExportEntriesReport(string outputPath, string sheetTitle, IEnumerable<Dictionary<string, object?>> rows)
    {
        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add(sheetTitle);
        var list = rows.ToList();
        if (list.Count == 0)
        {
            ws.Cell(1, 1).Value = "No records available for the selected filter.";
            wb.SaveAs(outputPath);
            return;
        }

        var headers = list[0].Keys.ToList();
        for (int c = 0; c < headers.Count; c++)
        {
            var cell = ws.Cell(1, c + 1);
            cell.Value = headers[c];
            cell.Style.Font.Bold = true;
            cell.Style.Font.FontColor = XLColor.White;
            cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#0B1528");
        }

        for (int r = 0; r < list.Count; r++)
        {
            for (int c = 0; c < headers.Count; c++)
            {
                var val = list[r][headers[c]];
                var cell = ws.Cell(r + 2, c + 1);
                cell.Value = val?.ToString() ?? string.Empty;
                if (headers[c] == "qa_status" || headers[c] == "severity")
                {
                    var s = val?.ToString();
                    if (s == "RED") cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#FEE2E2");
                    else if (s == "YELLOW") cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#FEF3C7");
                    else if (s == "GREEN") cell.Style.Fill.BackgroundColor = XLColor.FromHtml("#DCFCE7");
                }
            }
        }

        ws.SheetView.FreezeRows(1);
        ws.RangeUsed()?.SetAutoFilter();
        ws.Columns().AdjustToContents();
        wb.SaveAs(outputPath);
    }
}
