using Microsoft.Data.Sqlite;
using System.IO;

namespace BroadcastQA.Wpf.Services;

public sealed class SqliteRepository
{
    public string DatabasePath { get; }

    public SqliteRepository(string? customPath = null)
    {
        var appDir = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "BroadcastQAStudio");
        Directory.CreateDirectory(appDir);
        DatabasePath = customPath ?? Path.Combine(appDir, "broadcast_qa.db");
        EnsureSchema();
    }

    public SqliteConnection OpenConnection()
    {
        var conn = new SqliteConnection($"Data Source={DatabasePath};Mode=ReadWriteCreate");
        conn.Open();
        return conn;
    }

    public void BackupTo(string targetPath)
    {
        using var source = OpenConnection();
        using var dest = new SqliteConnection($"Data Source={targetPath}");
        dest.Open();
        source.BackupDatabase(dest);
    }

    private void EnsureSchema()
    {
        using var conn = OpenConnection();
        using var cmd = conn.CreateCommand();
        cmd.CommandText = """
            PRAGMA journal_mode=WAL;
            CREATE TABLE IF NOT EXISTS import_batches (
                id TEXT PRIMARY KEY, folder_name TEXT NOT NULL, imported_at TEXT NOT NULL,
                file_count INTEGER NOT NULL, records_inserted INTEGER NOT NULL,
                records_skipped_duplicate INTEGER NOT NULL, error_count INTEGER NOT NULL
            );
            CREATE TABLE IF NOT EXISTS channels (
                id TEXT PRIMARY KEY, channel_id TEXT, channel_name TEXT NOT NULL, is_selected INTEGER DEFAULT 0
            );
            CREATE TABLE IF NOT EXISTS entries (
                id TEXT PRIMARY KEY, dedup_fingerprint TEXT UNIQUE NOT NULL, batch_id TEXT NOT NULL,
                channel_key TEXT NOT NULL, channel_name TEXT NOT NULL, trans_date TEXT,
                entry_type TEXT NOT NULL, master_entry_id TEXT, segment_detail_id TEXT,
                commercial_id TEXT, caption_name TEXT, brand_name TEXT,
                category_name TEXT, subcategory_name TEXT,
                start_time TEXT, end_time TEXT, duration_seconds REAL,
                original_values_json TEXT NOT NULL, raw_xml TEXT NOT NULL,
                is_manually_edited INTEGER DEFAULT 0, qa_status TEXT DEFAULT 'PENDING'
            );
            CREATE TABLE IF NOT EXISTS qa_issues (
                id TEXT PRIMARY KEY, entry_id TEXT NOT NULL, channel_name TEXT NOT NULL,
                trans_date TEXT, severity TEXT NOT NULL, error_type TEXT NOT NULL,
                reason TEXT NOT NULL, confidence_level TEXT NOT NULL, resolution_status TEXT DEFAULT 'OPEN'
            );
            CREATE TABLE IF NOT EXISTS audit_logs (
                id INTEGER PRIMARY KEY AUTOINCREMENT, timestamp TEXT NOT NULL,
                entity_type TEXT NOT NULL, entity_id TEXT NOT NULL, action TEXT NOT NULL,
                field_name TEXT, old_value TEXT, new_value TEXT, notes TEXT
            );
            """;
        cmd.ExecuteNonQuery();
    }
}
