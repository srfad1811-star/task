[Setup]
AppName=BroadcastQA Studio
AppVersion=1.0.0
AppPublisher=BroadcastQA Enterprise
DefaultDirName={autopf}\BroadcastQA Studio
DefaultGroupName=BroadcastQA Studio
UninstallDisplayIcon={app}\BroadcastQAStudio.exe
OutputDir=..\dist-installer
OutputBaseFilename=BroadcastQAStudio_Setup_1.0.0
Compression=lzma2
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
WizardStyle=modern

[Files]
Source: "..\src\BroadcastQA.Wpf\bin\Release\net8.0-windows\win-x64\publish\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\BroadcastQA Studio"; Filename: "{app}\BroadcastQAStudio.exe"
Name: "{autodesktop}\BroadcastQA Studio"; Filename: "{app}\BroadcastQAStudio.exe"

[Run]
Filename: "{app}\BroadcastQAStudio.exe"; Description: "Launch BroadcastQA Studio"; Flags: nowait postinstall skipifsilent
