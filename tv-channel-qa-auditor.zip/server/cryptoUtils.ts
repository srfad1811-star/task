import crypto from 'node:crypto';

const MASTER_SECRET_RAW =
  process.env.STORAGE_ENCRYPTION_KEY ||
  process.env.SESSION_SECRET ||
  'broadcastqa-studio-default-local-key-change-in-production';

const AES_KEY = crypto.createHash('sha256').update(MASTER_SECRET_RAW).digest();

export function encryptSecret(plainText: string): string {
  if (!plainText) return '';
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', AES_KEY, iv);
  const encrypted = Buffer.concat([cipher.update(plainText, 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `enc:v1:${iv.toString('hex')}:${tag.toString('hex')}:${encrypted.toString('hex')}`;
}

export function decryptSecret(cipherText: string | null | undefined): string {
  if (!cipherText) return '';
  if (!cipherText.startsWith('enc:v1:')) {
    return cipherText;
  }
  try {
    const [, , ivHex, tagHex, dataHex] = cipherText.split(':');
    const decipher = crypto.createDecipheriv('aes-256-gcm', AES_KEY, Buffer.from(ivHex, 'hex'));
    decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
    const decrypted = Buffer.concat([
      decipher.update(Buffer.from(dataHex, 'hex')),
      decipher.final(),
    ]);
    return decrypted.toString('utf8');
  } catch {
    return '';
  }
}

export function maskSecret(value: string | null | undefined): string {
  if (!value) return '';
  if (value.length <= 6) return '••••••';
  return `${value.slice(0, 3)}••••••${value.slice(-3)}`;
}

export function signPlaybackToken(archiveId: string, expiresAtEpochSec: number): string {
  return crypto
    .createHmac('sha256', AES_KEY)
    .update(`playback:${archiveId}:${expiresAtEpochSec}`)
    .digest('hex');
}

export function verifyPlaybackToken(
  archiveId: string,
  expiresAtEpochSec: number,
  token: string
): boolean {
  if (!token || !Number.isFinite(expiresAtEpochSec)) return false;
  if (Math.floor(Date.now() / 1000) > expiresAtEpochSec) return false;
  const expected = signPlaybackToken(archiveId, expiresAtEpochSec);
  if (token.length !== expected.length) return false;
  return crypto.timingSafeEqual(Buffer.from(token), Buffer.from(expected));
}

export function generateSessionToken(): string {
  return crypto.randomBytes(32).toString('hex');
}

export function sha256FileBuffer(buf: Buffer): string {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

export function redactStreamCredentials(url: string): string {
  try {
    const parsed = new URL(url);
    if (parsed.username || parsed.password) {
      parsed.username = parsed.username ? '***' : '';
      parsed.password = parsed.password ? '***' : '';
    }
    for (const key of Array.from(parsed.searchParams.keys())) {
      if (/token|key|pass|secret|auth|sig/i.test(key)) {
        parsed.searchParams.set(key, '***');
      }
    }
    return parsed.toString();
  } catch {
    return url.replace(/(token|key|pass|secret|auth)=([^&\s]+)/gi, '$1=***');
  }
}
