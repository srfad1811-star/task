import express from 'express';
import { getDb, logAudit } from './db.ts';
import { generateSessionToken } from './cryptoUtils.ts';

const router = express.Router();

// Auth / User Login
router.post('/api/auth/login', (req, res) => {
  const { username, password } = req.body as { username?: string; password?: string };
  if (!username || !password) {
    res.status(400).json({ error: 'Username and password required.' });
    return;
  }
  const db = getDb();
  const user = db.prepare(`SELECT * FROM users WHERE username = ? AND is_active = 1`).get(username.trim()) as
    | { id: string; username: string; password_hash: string; full_name: string; role: string }
    | undefined;

  if (!user || user.password_hash !== password) {
    res.status(401).json({ error: 'Invalid username or password.' });
    return;
  }

  const token = generateSessionToken();
  const now = new Date();
  const expires = new Date(now.getTime() + 7 * 24 * 3600 * 1000);
  db.prepare(
    `INSERT INTO auth_sessions (token, user_id, username, role, created_at, expires_at)
     VALUES (?, ?, ?, ?, ?, ?)`
  ).run(token, user.id, user.username, user.role, now.toISOString(), expires.toISOString());

  logAudit({
    entityType: 'USER',
    entityId: user.id,
    action: 'USER_LOGIN',
    notes: `User ${user.username} logged in successfully`,
  });

  res.json({
    sessionToken: token,
    user: {
      id: user.id,
      username: user.username,
      fullName: user.full_name,
      role: user.role,
    },
  });
});

router.get('/api/users', (_req, res) => {
  const users = getDb()
    .prepare(`SELECT id, username, full_name, role, is_active, created_at FROM users ORDER BY username ASC`)
    .all();
  res.json(users);
});

router.post('/api/users', (req, res) => {
  const { username, password, fullName, role } = req.body as {
    username?: string;
    password?: string;
    fullName?: string;
    role?: string;
  };
  if (!username || !password || !fullName) {
    res.status(400).json({ error: 'Missing required user fields.' });
    return;
  }
  const db = getDb();
  const id = `usr_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`;
  try {
    db.prepare(
      `INSERT INTO users (id, username, password_hash, full_name, role, is_active, created_at)
       VALUES (?, ?, ?, ?, ?, 1, ?)`
    ).run(id, username.trim(), password, fullName.trim(), role || 'OPERATOR', new Date().toISOString());
    logAudit({ entityType: 'USER', entityId: id, action: 'USER_CREATED', notes: username });
    res.json({ ok: true, id });
  } catch (err) {
    res.status(400).json({ error: err instanceof Error ? err.message : 'User creation failed' });
  }
});

router.patch('/api/users/:id', (req, res) => {
  const { role, isActive, fullName } = req.body as { role?: string; isActive?: boolean; fullName?: string };
  const db = getDb();
  db.prepare(
    `UPDATE users SET
       role = COALESCE(?, role),
       is_active = COALESCE(?, is_active),
       full_name = COALESCE(?, full_name)
     WHERE id = ?`
  ).run(
    role || null,
    isActive !== undefined ? (isActive ? 1 : 0) : null,
    fullName || null,
    req.params.id
  );
  logAudit({ entityType: 'USER', entityId: req.params.id, action: 'USER_UPDATED', notes: `Updated user role/status` });
  res.json({ ok: true });
});

router.delete('/api/users/:id', (req, res) => {
  const db = getDb();
  db.prepare(`DELETE FROM users WHERE id = ?`).run(req.params.id);
  logAudit({ entityType: 'USER', entityId: req.params.id, action: 'USER_DELETED', notes: `Deleted user` });
  res.json({ ok: true });
});

export default router;
